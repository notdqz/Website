import { store } from './core/store.js';
import { applyTheme } from './core/theme.js';
import { startRouter, go } from './core/router.js';
import { BackgroundEngine } from './backgrounds/engine.js';
import { MouseEffects } from './effects/mouseEffects.js';
import { initInput, onKey } from './effects/input.js';
import { HUDManager } from './hud/manager.js';
import { AppUI } from './ui/app.js';
import { findByKey, toggleUtility } from './utilities/registry.js';
import { gameManager } from './games/manager.js';

const appUI=new AppUI();
const bg=new BackgroundEngine(document.querySelector('#bg-canvas'));
const fx=new MouseEffects(document.querySelector('#fx-canvas'));
const hud=new HUDManager(document.querySelector('#hud-layer'));
initInput();applyTheme();
startRouter(page=>{appUI.render(page);hud.render()});
document.addEventListener('nexus:app-render',()=>hud.render());
document.addEventListener('nexus:bg-change',()=>bg.seed());document.addEventListener('nexus:render-scale',()=>{bg.resize();fx.sync()});
bg.start();fx.start();

gameManager.init().then(()=>document.dispatchEvent(new CustomEvent('nexus:games-ready')));

onKey((e,down)=>{
 if(!down)return;
 if(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement)return;
 const def=findByKey(e.code)||findByKey(e.key);
 if(def){e.preventDefault();if(def.id==='console'){appUI.openConsole(location.hash.slice(1)||'home');return}toggleUtility(def.id);hud.render()}
});

let autoTimer=null;
function stopAuto(){if(autoTimer){clearInterval(autoTimer);autoTimer=null}store.set({autoclicker:{...store.get().autoclicker,enabled:false}})}
function startAuto(){stopAuto();const st=store.get();const cps=Math.max(1,Math.min(30,st.autoclicker.cps||10));const delay=1000/cps;store.set({autoclicker:{...st.autoclicker,enabled:true}});autoTimer=setInterval(()=>{if(store.get().autoclicker.mode==='hold' && !document.pointerLockElement && !document.querySelector(':hover'))return;const x=document.documentElement.style.getPropertyValue('--mx').replace('px','')||innerWidth/2;const y=document.documentElement.style.getPropertyValue('--my').replace('px','')||innerHeight/2;const target=document.elementFromPoint(Number(x),Number(y));target?.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,clientX:Number(x),clientY:Number(y),view:window}))},delay)}
document.addEventListener('nexus:autoclicker',e=>e.detail?.action==='start'?startAuto():stopAuto());

addEventListener('online',()=>appUI.render(location.hash.slice(1)||'home'));
addEventListener('offline',()=>appUI.render(location.hash.slice(1)||'home'));
function frame(t){hud.tick(t);requestAnimationFrame(frame)}requestAnimationFrame(frame);
