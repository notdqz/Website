export class BaseAIProvider{
  constructor(config={}){this.config=config}
  get configured(){return false}
  async send(){throw new Error('Provider is not configured')}
}
export class OpenAIProvider extends BaseAIProvider{get configured(){return !!this.config.endpoint && !!this.config.model && !!this.config.secretConfigured}}
export class AnthropicProvider extends BaseAIProvider{get configured(){return !!this.config.endpoint && !!this.config.model && !!this.config.secretConfigured}}
export class DeepSeekProvider extends BaseAIProvider{get configured(){return !!this.config.endpoint && !!this.config.model && !!this.config.secretConfigured}}
export const providerCatalog={
  openai:{name:'OpenAI',factory:c=>new OpenAIProvider(c)},
  anthropic:{name:'Claude',factory:c=>new AnthropicProvider(c)},
  deepseek:{name:'DeepSeek',factory:c=>new DeepSeekProvider(c)}
};
